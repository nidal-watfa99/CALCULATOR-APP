الحاسبة الشاملة | Smart Calculator
=========================================
Developer: NIDAL WATFA — nidalwatfa99@gmail.com

انظر ملف README.md للوصف الكامل والتعليمات والروابط.

See README.md for full documentation, usage and links.

Quick start:
1. Open index.html in a browser
2. Or: python -m http.server  then open http://localhost:8000
3. Install as PWA for offline use

New in this version:
- Live metal prices (Gold, Silver, Platinum, Palladium via Coinbase)
- Fuel & energy prices (manual + reference)
- Native Share button
- Expanded developer links
- Professional README + MIT License

Version notes:
- Fixed calculator engine (negative powers, (x)%, (x)!, 50+10%, double dots)
- Fixed tiny/huge number display, ratio simplifier, shoe-size conversion, console button
- Gold animated app title, golden icons, desktop shortcut installers
- GitHub Actions workflow for Pages deploy (.github/workflows/deploy-pages.yml)

Updates (2026-10-09):
- Full Scientific Calculator page (Casio fx-991ES PLUS inspired)
- Fixed age calculator (more precise breakdown)
- Cleaned Scientific Symbols UI (equation + answer + copy, no number spam)

Update (audit 2026-10-09):
- Scientific calculator rebuilt as a full independent page (SHIFT/ALPHA/HYP, DEG/RAD/GRA, inverse+hyperbolic trig, log/ln/log2/logb, nPr/nCr infix, Pol/Rec, root, factorial, STO/RCL variables A-F X Y M, constants, S<=>D fractions, history, caret editing) + EQN / STAT / BASE / TABLE modes.
- Fixed old engine bugs (ln, log, asin/acos/atan, sinh/cosh/tanh, abs were broken); sin(180)/cos(90) now exact; tan(90) = Math ERROR.
- +31 laws: geometry (Heron, sine/cosine rules, distance, slope, sector, trapezoid, polygon, ellipse), algebra (sequences, log base, exponential), physics (Coulomb, E-field, Lorentz, Planck, photoelectric, E=mc2, Kepler, Stefan, decay, ...), chemistry (pH, Avogadro, osmotic, Beer-Lambert, Gibbs, Graham).
